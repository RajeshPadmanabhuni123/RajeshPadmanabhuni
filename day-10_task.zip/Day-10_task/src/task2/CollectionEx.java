package task2;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.ListIterator;

public class CollectionEx {

	public static void main(String[] args) {
		
		
	}

}

