package task2;

public class Employee {

	String empid;
	String empname;
	double empsalary;
	int empage;
	public Employee(String empid, String empname, double empsalary, int empage) {
		super();
		this.empid = empid;
		this.empname = empname;
		this.empsalary = empsalary;
		this.empage = empage;
	}
	
}
