package com.arithmetic;

public class Arithmetic {
	public void add(int a,int b)
	{
		System.out.println("Addition : "+(a+b));
	}
	public void sub(int a,int b)
	{
		System.out.println("Subtraction : "+(a-b));
	}
	public void mul(int a,int b)
	{
		System.out.println("Multiplication : "+(a*b));
	}
	public void div(int a,int b)
	{
		System.out.println("Division : "+(a/b));
	}
	public void modDiv(int a,int b)
	{
		System.out.println("Modulo-Division : "+(a%b));
	}
	

}
