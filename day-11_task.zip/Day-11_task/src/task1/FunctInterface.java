/**
 * @Interface
 * @author RajeshPadmanabhuni
 * @16-Nov-2020
 * 
 */
package task1;

public interface FunctInterface {

	public void StringMethod(String a, String b);//unimplemented method
}
