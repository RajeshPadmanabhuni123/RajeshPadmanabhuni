/**
 * @Runnable Interface
 * @author RajeshPadmanabhuni
 * @16-Nov-2020
 * 
 */
package task2;

public interface Runnable {

	public void run();//un-implemeted method

}
