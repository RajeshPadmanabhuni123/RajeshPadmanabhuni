/**
 * @MyComparator
 * @author RajeshPadmanabhuni
 * @16-Nov-2020
 * 
 */
package task3;

public interface MyComparator {

	public int compare(Object o1,Object o2);//un-implemented method
}
