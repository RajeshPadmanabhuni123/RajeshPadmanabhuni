/**
 * @methodReference Example
 * @author RajeshPadmanabhuni
 * @16-Nov-2020
 * 
 */
package task6;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Wishes w=Wishing::greet; //method referencing
		w.Birthday();
	}

}
