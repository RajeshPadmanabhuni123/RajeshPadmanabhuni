/**
 * @General class
 * @author RajeshPadmanabhuni
 * @16-Nov-2020
 * 
 */
package task6;

public class Wishing {

	public static void greet()//static method (will be given as refernce)
	{
		System.out.println("Happy Birthday to you");
	}
}
