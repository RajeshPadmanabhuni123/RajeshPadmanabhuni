/**
 * @FunctionalInterface
 * @author RajeshPadmanabhuni
 * @16-Nov-2020
 * 
 */
package task6;

public interface Wishes {

	public void Birthday();//un-implemted method
}
