
public class MyExecption extends Exception {

	public MyExecption(String message)
	{
		super(message);
	}
}
