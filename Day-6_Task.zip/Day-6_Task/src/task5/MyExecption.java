package task5;

public class MyExecption extends Exception {

	public MyExecption()
	{
		
	}
	public MyExecption(Exception message)
	{
		System.out.println(message);
	}
}
