package task15;

public class Exception15 {

	Exception15() throws CloneNotSupportedException{
		throw new CloneNotSupportedException();
	}
}
