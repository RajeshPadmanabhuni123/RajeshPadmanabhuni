package task3;

public class Main {

	public static void main(String[] args) {
		Exercise7 e=new Exercise7();
		System.out.println(e.fileExists("rajesh.txt"));
		System.out.println(e.isInt("123"));
		System.out.println(e.isDouble("25"));
	}
}
