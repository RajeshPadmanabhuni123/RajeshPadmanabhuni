package task1;

import static org.junit.Assert.*;

import org.junit.Test;

import com.calculator.Calculator;

public class WithdrawTest {

	@Test
	public void testWithdraw() {
		 Account a=new Account("rajesh",12356789,1500);
		 float amount=100;
		 float fee=5;
		 boolean actual=a.withdraw(amount, fee);
		 boolean expected=true;
		 assertEquals(expected,actual);
	}
	
}
