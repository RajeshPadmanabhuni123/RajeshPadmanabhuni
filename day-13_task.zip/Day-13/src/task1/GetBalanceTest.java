package task1;

import static org.junit.Assert.*;

import org.junit.Test;

import com.calculator.Calculator;

public class GetBalanceTest {

	@Test
	public void testGetBalance() {
		 Account a=new Account("rajesh",12356789,1230);
		 float actual=1230;
		 float expected=a.getBalance();
		 assertEquals(expected,actual,0.001);
	}

}
