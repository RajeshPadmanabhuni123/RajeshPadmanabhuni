package task1;

import static org.junit.Assert.*;

import org.junit.Test;

import com.calculator.Calculator;

public class DepositTest {

	@Test
	public void testDeposit() {
		 Account a=new Account("rajesh",12356789,123);
		 float amount=100;
		 boolean actual=a.deposit(amount);
		 boolean expected=true;
		 assertEquals(expected,actual);
		
	}
}
