package task1;

import static org.junit.Assert.*;

import org.junit.Test;

public class GetAccountNumberTest {

	@Test
	public void testGetAccountNumber() {
		
		Account a=new Account("rajesh",12356789,1230);
		 long actual=12356789;
		 long expected=a.getAccountNumber();
		 assertEquals(expected,actual);
	}

}
