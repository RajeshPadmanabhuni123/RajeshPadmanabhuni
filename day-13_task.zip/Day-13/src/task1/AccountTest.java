package task1;


import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import org.junit.Before;
import org.junit.Test;

import com.calculator.Calculator;

public class AccountTest {

	@Test
	public void testAccount() {
		 Account a=new Account("rajesh",12356789,123);
		//System.out.println("done");
	}

}
