package task1;

import static org.junit.Assert.*;

import org.junit.Test;

import com.calculator.Calculator;


public class AddInterestTest {

	@Test
	public void testAddInterest() {
		 Account a=new Account("rajesh",12356789,1230);
		 float actual=1230+1230*a.kInterestRate;
		 float expected=a.addInterest();
		 assertEquals(expected,actual,0.001);
	}

}
