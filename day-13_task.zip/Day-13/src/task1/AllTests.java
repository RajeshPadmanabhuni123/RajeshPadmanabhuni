package task1;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ AccountTest.class, AddInterestTest.class, DepositTest.class, GetAccountNumberTest.class,
		GetBalanceTest.class, WithdrawTest.class })
public class AllTests {

}
