package com.calculator;

public class Calculator {

	public int addition(int number1,int number2)
	{
		return number1+number2;
	}
	
	public int division(int number1,int number2)
	{
		return number1/number2;
	}
}
