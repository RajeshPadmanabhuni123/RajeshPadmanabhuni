package com.hcl;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;



public class PrintingFileContent {

	public void printName(String filename) throws IOException
	{
		FileWriter fw=new FileWriter(filename+".txt");
		fw.write(filename);
		FileReader fr=new FileReader(filename+".txt");
		int i=fr.read();
		String str="";
		while(i!=-1)
		{
			str=str+i;
		}
		System.out.println(str);
		
	}
	public static void main(String[] args) throws IOException {
		PrintingFileContent pf=new PrintingFileContent();
		pf.printName("rajesh");
	}
}
