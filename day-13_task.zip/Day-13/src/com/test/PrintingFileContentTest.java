package com.test;



import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import org.junit.Test;

import com.hcl.PrintingFileContent;

class PrintingFileContentTest {

	@Test
	void testPrintName() throws IOException {
		FileWriter fw=new FileWriter("rajesh.txt");
		FileReader fr=new FileReader("rajesh.txt");
		int i=fr.read();
		while(i!=-1)
		{
			System.out.println(i);
		}
		
	}

}
