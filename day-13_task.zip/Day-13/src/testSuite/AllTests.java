package testSuite;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({SomeMessagesTest2.class,SomeMessagesTest2.class,SomeMessagesTest3.class})
public class AllTests {

}
