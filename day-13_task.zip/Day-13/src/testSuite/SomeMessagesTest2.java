package testSuite;



import static org.junit.Assert.assertEquals;

import org.junit.Test;


public class SomeMessagesTest2 {

	String message="rajesh";
	SomeMessages sm=new SomeMessages(message);
	@Test
	public void testPrintMessage() {
		assertEquals(message,sm.printMessage());

	}

}
