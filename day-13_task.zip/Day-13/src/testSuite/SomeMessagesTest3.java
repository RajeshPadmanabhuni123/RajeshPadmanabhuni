package testSuite;



import static org.junit.Assert.assertEquals;

import org.junit.Test;


public class SomeMessagesTest3 {

	String message="rajesh";
	SomeMessages sm=new SomeMessages(message);
	@Test
	public void testAppendMessage() {
		message="hello "+message;
		assertEquals(message,sm.appendMessage());
		}

}
