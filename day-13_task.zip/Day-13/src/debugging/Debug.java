package debugging;

public class Debug {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Debug d=new Debug();
		d.loop(10);
		
	}
	public void loop(int num)
	{
		for(int i=0;i<num;i++)
		{
			print(i);
		}
	}
	public void print(int i)
	{
		System.out.println(i);
	}
}
