package test;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import com.calculator.Calculator;

class CalculatorTest {
	static Calculator c;
	@Before
	void assignCalculator()
	{
		c=new Calculator();
	}
	@Test
	void testAddition() {
		
		int actualvalue=c.addition(1, 2);
		int expectedvalue=3;
		
		assertEquals(expectedvalue,actualvalue);
	}
	void testDivision() {		
		
		assertThrows(ArithmeticException.class,()->c.division(3,0));
	}

}
