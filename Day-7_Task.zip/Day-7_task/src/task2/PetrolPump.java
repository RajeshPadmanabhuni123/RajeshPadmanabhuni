package task2;


public class PetrolPump {

	public static void main(String[] args) {
		Cars c1=new Cars();
		Cars2 c2=new Cars2();
		Cars3 c3=new Cars3();
		Cars4 c4=new Cars4();
		Cars5 c5=new Cars5();
		Cars6 c6=new Cars6();
		c1.start();
		c2.start();
		c3.start();
		c4.start();
		c5.start();
		c6.start();
	}
}
