package Student2;
/*Base class*/
public class Student1 {

	String name;
	String rollnumber;
	String address;
	Student1()
	{
		//default-constructor
	}	
	
}
