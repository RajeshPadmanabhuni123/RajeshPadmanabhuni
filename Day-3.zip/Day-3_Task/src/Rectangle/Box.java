package Rectangle;

public class Box extends Rectangle{
	int depth;	
}