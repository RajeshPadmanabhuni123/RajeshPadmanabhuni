package com.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class StudentEx {

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub

	
		Scanner sc=new Scanner(System.in);
		String url="jdbc:mysql://localhost:3306/hero"; //local-host & db-name
		System.out.println("Enter username");
		String user=sc.next(); //password
		System.out.println("Enter password");
		String password=sc.next(); //username
		Connection con=null;
		try //getting connection
		{ 
			con=DriverManager.getConnection(url,user,password);
			System.out.println("Welcome to student management system :");
			System.out.println("choose from following options :");
			System.out.println("1. Add student");
			System.out.println("2. Remove student");
			System.out.println("3. update student");
			System.out.println("4. display students");
			System.out.println("5. logout");
			Class.forName("com.mysql.cj.jdbc.Driver"); //loading driver class
			
			Statement st=con.createStatement(); //creating statement
			
			
			System.out.println("Enter your choice");
			int ch=sc.nextInt();
			switch(ch)
			{
				case 1:
				{
					st.executeUpdate("insert into customer values(6,'keerthi','nellore')"); //Resultset generation
					
					/*while(rs.next()) //printing values in result set
					{
						System.out.println(rs.getInt(1)+" | "+rs.getString(2)+" | "+rs.getString(3));
					}*/
					break;
				}
				case 3:
				{
					st.executeUpdate("update customer set customername='rajeshr' where customerid=1"); //Resultset generation
					
					/*while(rs.next()) //printing values in result set
					{
						System.out.println(rs.getInt(1)+" | "+rs.getString(2)+" | "+rs.getString(3));
					}*/
					break;
				}
			
				case 2:
				{
					st.executeUpdate("delete from customer where customerid=1"); //Resultset generation
					
					/*while(rs.next()) //printing values in result set
					{
						System.out.println(rs.getInt(1)+" | "+rs.getString(2)+" | "+rs.getString(3));
					}*/
					break;
				}
				case 4:
				{
					ResultSet rs=st.executeQuery("select * from customer"); //Resultset generation
					
					while(rs.next()) //printing values in result set
					{
						System.out.println(rs.getInt(1)+" | "+rs.getString(2)+" | "+rs.getString(3));
					}
					break;
				}
				case 5:
					break;
			}
			
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			con.close();
		}
		System.out.println();
		System.out.println("Thanks for using.... !!");
		
	}

}
