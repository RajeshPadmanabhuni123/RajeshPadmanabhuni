package com.src;

import static org.junit.Assert.*;
import java.util.ArrayList;
import java.util.List;
import org.easymock.EasyMock;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.main.dao.TeacherDao;
import com.main.model.Admin;
import com.main.model.Teacher;
import com.main.model.TeacherFeedback;
import com.main.service.TeacherServiceImpl;

public class TeacherDaoImplTest {

    private static final Logger log = LoggerFactory.getLogger(StudentDaoImplTest.class);

	@Test
	public void testFetchTeacherList() {
		log.info("Inside testFetchTeacherList method in TeacherDao Test class");

		TeacherDao daoproxy=EasyMock.createMock(TeacherDao.class);
		
		Teacher s1=new Teacher(1,"rajesh","rajesh#");
		Teacher s2=new Teacher(2,"shiva","shiva#");
		
		List<Teacher> list=new ArrayList<Teacher>();
		list.add(s1);
		list.add(s2);

		EasyMock.expect(daoproxy.fetchTeacherList()).andReturn(list);
		
		EasyMock.replay(daoproxy);
		
		TeacherServiceImpl ssi=new TeacherServiceImpl();
		ssi.setTeacherdao(daoproxy);
		
		List<Teacher> list1=ssi.fetchTeacherList();
		
		assertNotNull(list1);
		assertEquals(list1, list);	
		
	}

	@Test
	public void testFetchFeedbackList() {
		log.info("Inside testFetchFeedbackList method in TeacherDao Test class");

		TeacherDao daoproxy=EasyMock.createMock(TeacherDao.class);
		
		TeacherFeedback s1=new TeacherFeedback(1,"rajesh","good at solving doubts","nothing","need to improve his presentation skills",4);
		TeacherFeedback s2=new TeacherFeedback(1,"rajesh","good at explaining","nothing","need to improve his presentation skills",4);

		TeacherFeedback s3=new TeacherFeedback(2,"shiva","Naratting examples very good","nothing","very good, nothing to say",5);
		TeacherFeedback s4=new TeacherFeedback(2,"shiva","good teaching skills","nothing","Excellent, nothing to say",5);

		List<TeacherFeedback> list=new ArrayList<TeacherFeedback>();
		list.add(s1);
		list.add(s2);
		
		List<TeacherFeedback> list1=new ArrayList<TeacherFeedback>();
		list.add(s3);
		list.add(s4);

		EasyMock.expect(daoproxy.fetchFeedbackList("rajesh")).andReturn(list);
		EasyMock.expect(daoproxy.fetchFeedbackList("shiva")).andReturn(list1);
		
		EasyMock.replay(daoproxy);
		
		TeacherServiceImpl ssi=new TeacherServiceImpl();
		ssi.setTeacherdao(daoproxy);
		
		List<TeacherFeedback> list2=ssi.fetchFeedbackList("shiva");
		
		assertNotNull(list2);
		assertEquals(list2, list1);	
	}

	@Test
	public void testFetchAdminList() {
		log.info("Inside testFetchAdminList method in TeacherDao Test class");

		TeacherDao daoproxy=EasyMock.createMock(TeacherDao.class);
		
		Admin s1=new Admin(1,"venkatesh","venkatesh#");
		Admin s2=new Admin(2,"naresh","naresh$");
		
		List<Admin> list=new ArrayList<Admin>();
		list.add(s1);
		list.add(s2);

		EasyMock.expect(daoproxy.fetchAdminList()).andReturn(list);
		
		EasyMock.replay(daoproxy);
		
		TeacherServiceImpl ssi=new TeacherServiceImpl();
		ssi.setTeacherdao(daoproxy);
		
		List<Admin> list1=ssi.fetchAdminList();
		
		assertNotNull(list1);
		assertEquals(list1, list);
	}

}
