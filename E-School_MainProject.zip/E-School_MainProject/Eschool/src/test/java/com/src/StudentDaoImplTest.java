package com.src;

import static org.junit.Assert.*;
import java.util.ArrayList;
import java.util.List;
import org.easymock.EasyMock;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.main.dao.StudentDao;
import com.main.model.Enotes;
import com.main.model.Fee;
import com.main.model.Student;
import com.main.model.StudentFeedback;
import com.main.model.TimeTable;
import com.main.service.StudentServiceImpl;

public class StudentDaoImplTest {

    private static final Logger log = LoggerFactory.getLogger(StudentDaoImplTest.class);

	
	@Test
	public void testFetchStudentList() {
		log.info("Inside testFetchStudentList method in StudentDao Test class");
		StudentDao daoproxy=EasyMock.createMock(StudentDao.class);
		
		Student s1=new Student(1,"pk","pk#","class-I","fn","mn","12-10-2020","pk@gmail.com");
		Student s2=new Student(2,"ck","ck#","class-II","fn","mn","13-11-2010","ck@gmail.com");
		List<Student> list=new ArrayList<Student>();
		list.add(s1);
		list.add(s2);

		EasyMock.expect(daoproxy.fetchStudentList()).andReturn(list);
		
		EasyMock.replay(daoproxy);
		
		StudentServiceImpl ssi=new StudentServiceImpl();
		ssi.setStudentdao(daoproxy);
		
		List<Student> list1=ssi.fetchStudentList();
		
		assertNotNull(list1);
		assertEquals(list1, list);
	}

	@Test
	public void testFetchTimeTableList() {
		log.info("Inside testFetchTimeTableList method in StudentDao Test class");

		StudentDao daoproxy=EasyMock.createMock(StudentDao.class);
		
		TimeTable s1=new TimeTable(1,"class-I","9:00am to 10:am","shiva","java","http://www.teams.java.com","12-12-2020");
		TimeTable s2=new TimeTable(2,"class-I","10:30am to 12:30pm","rajesh","Web development","http://www.teams.web_development.com","13-12-2020");
		
		//Timetable for class-I
		List<TimeTable> list=new ArrayList<TimeTable>();
		list.add(s1);
		list.add(s2);
		
		TimeTable s4=new TimeTable(3,"class-II","9:00am to 10:am","vishnu","Web development","http://www.teams.web_development.com","13-12-2020");
		TimeTable s3=new TimeTable(4,"class-II","10:30am to 12:30pm","kumar","java","http://www.teams.java.com","12-12-2020");
		
		//Timetable for class-II
		List<TimeTable> list1=new ArrayList<TimeTable>();
		list1.add(s3);
		list1.add(s4);

		EasyMock.expect(daoproxy.fetchTimeTableList("class-I")).andReturn(list);
		EasyMock.expect(daoproxy.fetchTimeTableList("class-II")).andReturn(list1);
		
		EasyMock.replay(daoproxy);
		
		StudentServiceImpl ssi=new StudentServiceImpl();
		ssi.setStudentdao(daoproxy);
		
		List<TimeTable> list2=ssi.fetchTimeTableList("class-I");
		
		assertNotNull(list1);
		assertEquals(list2, list);	
	}

	@Test
	public void testFetchEnotesList() {
		
		log.info("Inside testFetchEnotesList method in StudentDao Test class");

		StudentDao daoproxy=EasyMock.createMock(StudentDao.class);
		
		Enotes s1=new Enotes("class-I","JAVA","Polymorphism","http://www.teams.java.com","Write an example of polymorphism","Shiva");
		Enotes s2=new Enotes("class-I","JAVA","inheritence","http://www.teams.java.com","Write an example of inheritence","Shiva");
		
		//Timetable for class-I
		List<Enotes> list=new ArrayList<Enotes>();
		list.add(s1);
		list.add(s2);
		
		Enotes s3=new Enotes("class-II","JAVA","Encapsulation","http://www.teams.java.com","Write an example of Encapsulation","Shiva");
		Enotes s4=new Enotes("class-II","JAVA","OOPS","http://www.teams.java.com","Write an example of OOPS","Shiva");
		
		//Timetable for class-II
		List<Enotes> list1=new ArrayList<Enotes>();
		list1.add(s3);
		list1.add(s4);

		EasyMock.expect(daoproxy.fetchEnotesList("class-I")).andReturn(list);
		EasyMock.expect(daoproxy.fetchEnotesList("class-II")).andReturn(list1);

		EasyMock.replay(daoproxy);
		
		StudentServiceImpl ssi=new StudentServiceImpl();
		ssi.setStudentdao(daoproxy);
		
		List<Enotes> list2=ssi.fetchEnotesList("class-I");

		assertNotNull(list1);
		assertEquals(list2, list);
	}

	@Test
	public void testFetchFeeList() {
		log.info("Inside testFetchFeeList method in StudentDao Test class");

		StudentDao daoproxy=EasyMock.createMock(StudentDao.class);
		
		Fee s1=new Fee(1,"Rajesh","Class-I","Regular",25000,"19-12-2020","pending");
		Fee s2=new Fee(2,"kumar","Class-II","Regular",22000,"19-12-2020","Paid");
		
		//Fee of studentid-1
		List<Fee> list=new ArrayList<Fee>();
		list.add(s1);
		//Fee of studentid-2
		List<Fee> list1=new ArrayList<Fee>();
		list1.add(s2);
	
		EasyMock.expect(daoproxy.fetchFeeList(1)).andReturn(list);
		EasyMock.expect(daoproxy.fetchFeeList(2)).andReturn(list1);
		
		EasyMock.replay(daoproxy);
		
		StudentServiceImpl ssi=new StudentServiceImpl();
		ssi.setStudentdao(daoproxy);
		
		List<Fee> list2=ssi.fetchFeeList(1);
		
		assertNotNull(list1);
		assertEquals(list2, list);
	}

	@Test
	public void testFetchFeedbackList() {
		log.info("Inside testFetchFeedbackList method in StudentDao Test class");

		StudentDao daoproxy=EasyMock.createMock(StudentDao.class);
		
		StudentFeedback s1=new StudentFeedback(1,"Good girl","rajesh");
		StudentFeedback s2=new StudentFeedback(1,"Hardworking person","shiva");
		
		//Feedback of studentid-1
		List<StudentFeedback> list=new ArrayList<StudentFeedback>();
		list.add(s1);
		list.add(s2);
		
		StudentFeedback s3=new StudentFeedback(2,"This student has more innovative thoughts student","rajesh");
		StudentFeedback s4=new StudentFeedback(2,"Very good boy","shiva");
		
		//Feedback of studentid-2
		List<StudentFeedback> list1=new ArrayList<StudentFeedback>();
		list1.add(s3);
		list1.add(s4);
	
		EasyMock.expect(daoproxy.fetchFeedbackList(1)).andReturn(list);
		EasyMock.expect(daoproxy.fetchFeedbackList(2)).andReturn(list1);

		EasyMock.replay(daoproxy);
		
		StudentServiceImpl ssi=new StudentServiceImpl();
		ssi.setStudentdao(daoproxy);
		
		List<StudentFeedback> list2=ssi.fetchFeedbackList(1);
		assertNotNull(list1);
		assertEquals(list2, list);
	}

	@Test
	public void testGetStudentById() {
		log.info("Inside testGetStudentById method in StudentDao Test class");

		StudentDao daoproxy=EasyMock.createMock(StudentDao.class);
		
		Student s1=new Student(1,"pk","pk#","class-I","fn","mn","12-10-2020","pk@gmail.com");
		Student s2=new Student(2,"ck","ck#","class-II","fn","mn","13-11-2010","ck@gmail.com");

		EasyMock.expect(daoproxy.getStudentById(1)).andReturn(s1);
		EasyMock.expect(daoproxy.getStudentById(2)).andReturn(s2);
		
		EasyMock.replay(daoproxy);
		
		StudentServiceImpl ssi=new StudentServiceImpl();
		ssi.setStudentdao(daoproxy);
		
		Student s3=ssi.getStudentById(1);
		
		assertNotNull(s3);
		assertEquals(s3, s1);
		
	}
	
	@Test
	public void testGetEnotesByEnotesId() {
		log.info("Inside testGetEnotesByEnotesId method in StudentDao Test class");

		StudentDao daoproxy=EasyMock.createMock(StudentDao.class);
		
		Enotes s1=new Enotes("class-II","JAVA","Encapsulation","http://www.teams.java.com","Write an example of Encapsulation","Shiva");
		Enotes s2=new Enotes("class-II","JAVA","OOPS","http://www.teams.java.com","Write an example of OOPS","Shiva");

		EasyMock.expect(daoproxy.getEnotesByEnotesId(1)).andReturn(s1);
		EasyMock.expect(daoproxy.getEnotesByEnotesId(2)).andReturn(s2);
		
		EasyMock.replay(daoproxy);
		
		StudentServiceImpl ssi=new StudentServiceImpl();
		ssi.setStudentdao(daoproxy);
		
		Enotes s3=ssi.getEnotesByEnotesId(1);
		
		assertNotNull(s3);
		assertEquals(s3, s1);
		
	}
	
	public void testGetTimeTableByTimeTableId() {
		log.info("Inside testGetTimeTableByTimeTableId method in StudentDao Test class");

		StudentDao daoproxy=EasyMock.createMock(StudentDao.class);
		
		TimeTable s1=new TimeTable(1,"class-I","9:00am to 10:am","shiva","java","http://www.teams.java.com","12-12-2020");
		TimeTable s2=new TimeTable(2,"class-I","10:30am to 12:30pm","rajesh","Web development","http://www.teams.web_development.com","13-12-2020");
		
		EasyMock.expect(daoproxy.getTimeTableByTimeTableId(1)).andReturn(s1);
		EasyMock.expect(daoproxy.getTimeTableByTimeTableId(2)).andReturn(s2);
		
		EasyMock.replay(daoproxy);
		
		StudentServiceImpl ssi=new StudentServiceImpl();
		ssi.setStudentdao(daoproxy);
		
		TimeTable s3=ssi.getTimeTableByTimeTableId(1);
		
		assertNotNull(s3);
		assertEquals(s3, s1);
	}
}
