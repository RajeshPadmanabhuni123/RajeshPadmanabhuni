package com.main.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import org.hibernate.validator.constraints.NotEmpty;


@Entity
@Table(name = "fee")
public class Fee {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer FeeId;
	
	private Integer studentId;
	@NotEmpty
	private String studentName;
	@NotEmpty
	private String standard;
	@NotEmpty
	private String feeType;
	@NotNull
	private Integer amount;
	@NotEmpty
	private String dueDate;
	@NotEmpty
	private String status;
	
	public Fee() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Fee(Integer feeId, Integer studentId, String studentName, String standard,String feeType, Integer amount, String dueDate,
			String status) {
		super();
		FeeId = feeId;
		this.studentId = studentId;
		this.studentName = studentName;
		this.standard = standard;
		this.feeType=feeType;
		this.amount = amount;
		this.dueDate = dueDate;
		this.status = status;
	}
	public Fee(Integer studentId, String studentName, String standard,String feeType, Integer amount, String dueDate, String status) {
		super();
		this.studentId = studentId;
		this.studentName = studentName;
		this.standard = standard;
		this.feeType=feeType;
		this.amount = amount;
		this.dueDate = dueDate;
		this.status = status;
	}
	public Integer getFeeId() {
		return FeeId;
	}
	public void setFeeId(Integer feeId) {
		FeeId = feeId;
	}
	public Integer getStudentId() {
		return studentId;
	}
	public void setStudentId(Integer studentId) {
		this.studentId = studentId;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public String getStandard() {
		return standard;
	}
	public void setStandard(String standard) {
		this.standard = standard;
	}
	
	public String getFeeType() {
		return feeType;
	}
	public void setFeeType(String feeType) {
		this.feeType = feeType;
	}
	public Integer getAmount() {
		return amount;
	}
	public void setAmount(Integer amount) {
		this.amount = amount;
	}
	public String getDueDate() {
		return dueDate;
	}
	public void setDueDate(String dueDate) {
		this.dueDate = dueDate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	@Override
	public String toString() {
		return "Fee [FeeId=" + FeeId + ", studentId=" + studentId + ", studentName=" + studentName + ", standard="
				+ standard + ", feeType=" + feeType + ", amount=" + amount + ", dueDate=" + dueDate + ", status="
				+ status + "]";
	}
	
	
	
}
