package com.main.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import org.hibernate.validator.constraints.NotEmpty;


@Entity
@Table(name = "enotes")
public class Enotes {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer enotesId;
	@NotEmpty
	private String standard;
	@NotEmpty
	private String subject;
	@NotEmpty
	private String topic;
	@NotEmpty
	private String notes;
	@NotEmpty
	private String assignment;
	@NotEmpty
	private String teacher;

	public Enotes() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Enotes(Integer enotesId, String standard, String subject, String topic, String notes, String assignment,
			String teacher) {
		super();
		this.enotesId = enotesId;
		this.standard = standard;
		this.subject = subject;
		this.topic = topic;
		this.notes = notes;
		this.assignment = assignment;
		this.teacher = teacher;
	}

	public Enotes(String standard, String subject, String topic, String notes, String assignment, String teacher) {
		super();
		this.standard = standard;
		this.subject = subject;
		this.topic = topic;
		this.notes = notes;
		this.assignment = assignment;
		this.teacher = teacher;
	}

	public Integer getEnotesId() {
		return enotesId;
	}

	public void setEnotesId(Integer enotesId) {
		this.enotesId = enotesId;
	}

	public String getStandard() {
		return standard;
	}

	public void setStandard(String standard) {
		this.standard = standard;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getTopic() {
		return topic;
	}

	public void setTopic(String topic) {
		this.topic = topic;
	}

	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	public String getAssignment() {
		return assignment;
	}

	public void setAssignment(String assignment) {
		this.assignment = assignment;
	}

	public String getTeacher() {
		return teacher;
	}

	public void setTeacher(String teacher) {
		this.teacher = teacher;
	}

	@Override
	public String toString() {
		return "Enotes [enotesId=" + enotesId + ", standard=" + standard + ", subject=" + subject + ", topic=" + topic
				+ ", notes=" + notes + ", assignment=" + assignment + ", teacher=" + teacher + "]";
	}

}
