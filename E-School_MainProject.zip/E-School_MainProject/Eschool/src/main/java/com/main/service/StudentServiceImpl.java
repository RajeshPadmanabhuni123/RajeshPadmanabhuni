package com.main.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.main.dao.StudentDao;
import com.main.model.Enotes;
import com.main.model.Fee;
import com.main.model.Student;
import com.main.model.StudentFeedback;
import com.main.model.TimeTable;

@Service
@Transactional
public class StudentServiceImpl implements StudentService {

	private static Logger log = Logger.getLogger(StudentServiceImpl.class);
	@Autowired
	private StudentDao studentdao;
	


	
	public void setStudentdao(StudentDao studentdao) {
		log.info("Inside setStudentdao Method of StudentService layer");

		this.studentdao = studentdao;
	}



	public void saveStudent(Student student) {
		log.info("Inside saveStudent Method of StudentService layer");

		log.info("Passing Student Information to Dao Layer from Service Layer");
		studentdao.saveStudent(student);
		
	}


	
	public List<Student> fetchStudentList() {
		log.info("Inside fetchStudentList Method of StudentService layer");
		List<Student> list  = studentdao.fetchStudentList();
		return list;
	}


	
	public List<TimeTable> fetchTimeTableList(String standard) {
		log.info("Inside fetchTimeTableList Method of StudentService layer");

		List<TimeTable> list  = studentdao.fetchTimeTableList(standard);
		return list;
	}
	

	
	public List<Enotes> fetchEnotesList(String standard) {
		log.info("Inside fetchEnotesList Method of StudentService layer");

		List<Enotes> list  = studentdao.fetchEnotesList(standard);
		return list;
	}
	
	
	public List<Fee> fetchFeeList(Integer studentId) {
		log.info("Inside fetchFeeList Method of StudentService layer");

		List<Fee> feelist  = studentdao.fetchFeeList(studentId);
		return feelist;
	}



	public void TeacherFeedback(com.main.model.TeacherFeedback teacherFeedback) {
		log.info("Inside TeacherFeedback Method of StudentService layer");

		// TODO Auto-generated method stub
		studentdao.saveFeedback(teacherFeedback);
	}



	public List<StudentFeedback> fetchFeedbackList(Integer studentid) {
		log.info("Inside fetchFeedbackList Method of StudentService layer");

		List<StudentFeedback> feedbacklist  = studentdao.fetchFeedbackList(studentid);
		return feedbacklist;
	}



	public void updateStudent(Student student) {
		log.info("Inside updateStudent Method of StudentService layer");

		studentdao.updateStudent(student);
	}



	public void removeStudent(int studentid) {
		log.info("Inside removeStudent Method of StudentService layer");
		studentdao.removeStudent(studentid);
	}


	public Student getStudentById(int studentid) {
		log.info("Inside getStudentById Method of StudentService layer");
		return studentdao.getStudentById(studentid);
	}



	public void removeEnotes(int enotesId) {
		log.info("Inside removeEnotes Method of StudentService layer");
		studentdao.removeEnotes(enotesId);
	}



	public Enotes getEnotesByEnotesId(int enotesId) {
		// TODO Auto-generated method stub
		log.info("Inside getEnotesByEnotesId Method of StudentService layer");
		return studentdao.getEnotesByEnotesId(enotesId);
	}



	public void removeTimeTable(int timeTableId) {
		// TODO Auto-generated method stub
		log.info("Inside removeTimeTable Method of StudentService layer");
		studentdao.removeTimeTable(timeTableId);
	}



	public TimeTable getTimeTableByTimeTableId(int timeTableId) {
		// TODO Auto-generated method stub
		log.info("Inside getTimeTableByTimeTableId Method of StudentService layer");
		return studentdao.getTimeTableByTimeTableId(timeTableId);
	}
}