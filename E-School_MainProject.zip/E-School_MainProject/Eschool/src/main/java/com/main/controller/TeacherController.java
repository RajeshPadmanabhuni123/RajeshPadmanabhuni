package com.main.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.main.model.Enotes;
import com.main.model.Fee;
import com.main.model.Student;
import com.main.model.StudentFeedback;
import com.main.model.Teacher;
import com.main.model.TeacherFeedback;
import com.main.model.TimeTable;
import com.main.service.StudentService;
import com.main.service.TeacherService;


@Controller
public class TeacherController {

	private static final Logger log = LoggerFactory.getLogger(TeacherController.class);
	
	@Autowired
	private StudentService studentservice;
	
	@Autowired
	private StudentService studentservice1;
	
	@Autowired
	private TeacherService teacherservice;
	
	Teacher CurrentTeacher;
	
			//To home page
			@RequestMapping(value = "/home")
			public String home() {
				log.info("Inside HomePage method in teacher controller class");
				return "HomePage";
			}
			
			//To teacherhome page
			@RequestMapping(value = "/TeacherHome")
			public String teacherhome() {
				log.info("Inside TeacherHome  method in teacher controller class");
				return "TeacherHome";
			}
	
			//To selectStandard page
			@RequestMapping(value = "/standardSelect", method = RequestMethod.GET)
			public String standardSelect() {
				log.info("Inside standardSelect  method in teacher controller class");
				return "standardSelect";
			}
			
			String selectedStandard=null;
			
			@RequestMapping(value="/selected/{standard}")
			public String test(@PathVariable("standard") String stand) {
				log.info("Inside viewdetails  method in teacher controller class");
			System.out.println(stand);
			selectedStandard=stand;
			return "viewDetails";
			}
			
			
			//To selectID page
			@RequestMapping(value = "/teacherCheckFee", method = RequestMethod.GET)
			public String selectID(ModelMap map) {
				log.info("Inside selectID  method in teacher controller class");
				Student student=new Student();
				map.addAttribute("studentid",student);
				return "selectID";
			}
			
			@RequestMapping(value="/selectedid")
			public String test(@ModelAttribute("studentform") Student student, ModelMap map) {
				log.info("Inside Feedetails  method in teacher controller class");
			System.out.println(student.getStudentid());
			List<Fee> feelist= studentservice.fetchFeeList(student.getStudentid());
			System.out.println(feelist);
			map.addAttribute("feelist", feelist);
			return "FeeDetailsTeacher";
			}
			
			//Display timetable details
			@RequestMapping(value = "/teacherDisplayTimeTable")
			public String fetchTimeTable(ModelMap map) {
				log.info("Inside teacherDisplayTimeTable  method in teacher controller class");
				List<TimeTable> timetablelist = studentservice.fetchTimeTableList(selectedStandard);
				map.addAttribute("timetablelist", timetablelist);
				return "DisplayTimeTableTeacher";
			}
			
			//Display Enotes details
			@RequestMapping(value = "/teacherDisplayEnotes")
			public String fetchEnotes(ModelMap map) {
				log.info("Inside teacherDisplayEnotes method in teacher controller class");
				List<Enotes> enoteslist = studentservice.fetchEnotesList(selectedStandard);
				map.addAttribute("enoteslist", enoteslist);
				return "DisplayENotesTeacher";
			}
			
	        //To update Fee
			@RequestMapping(value = "/addFee", method = RequestMethod.GET)
			public String addFee(ModelMap map) {
				log.info("Inside addFee method in controller class");
				Fee fee=new Fee();
				map.addAttribute("feeform",fee);
				return "UpdateFee";
			}
			
			//Save Fee details
			@RequestMapping(value = "/saveFee", method = RequestMethod.POST)
			public String saveFee(@Validated @ModelAttribute("feeform") Fee fee,
					BindingResult result, ModelMap map) {
				log.info("Inside saveFee Method  method in teacher controller class");
				String viewname;
				if (result.hasErrors()) {
					log.info("Error while saving in Teacher Controller");
					viewname = "UpdateFee";
				} else {
					log.info("saving in Teacher Controller");
					teacherservice.saveFee(fee);
					viewname = "AdminHome";
				}
				return viewname;
			}
		
	
	
	//To Teacher Login
	@RequestMapping(value = "/teacherLogin")
	public String viewteacher(ModelMap model) {
		log.info("Inside viewteacher Method  method in teacher controller class");

		model.addAttribute("teacher", new Teacher());
		return "TeacherLogin";
	}
	
	//Authenticate Teacher
	@RequestMapping(value="/authenticateTeacher", method= RequestMethod.POST)
	public String authenticateUser(@ModelAttribute("teacher") Teacher user,
			ModelMap model) {
		log.info("Inside authenticate teacher method in teacher controller class");

		String msg=" ";
		String view=null;
		int i=0;
		List<Teacher> list=teacherservice.fetchTeacherList();
		for(Teacher tchr:list)
		{
			if(user.getTeacherId().equals(tchr.getTeacherId()) && user.getPassword().equals(tchr.getPassword()))
			{
				i++;
				CurrentTeacher=tchr;
				System.out.println(CurrentTeacher);
				
				view="TeacherHome";
			}
		}
		if(i==0){
			msg="Invalid Credentials!! Please Check";
			System.out.println(msg);
			view="TeacherLogin";
			model.addAttribute("msg",msg);
			System.out.println("Not foound");
		}
		return view;
	}
	
	
	
	
	
	//To update Student details
	@RequestMapping(value = "/addStudent", method = RequestMethod.GET)
	public String addStudent(ModelMap map) {
		log.info("Inside addStudent method in teacher controller class");
		Student student=new Student();
		map.addAttribute("listStudents", this.studentservice.fetchStudentList());
		//System.out.println(this.studentservice.fetchStudentList());
		map.addAttribute("studentform",student);
		return "StudentRegistration";
	}
	
	//Save Student details
	@RequestMapping(value = "/saveStudent", method = RequestMethod.POST)
	public String saveStudent(@Validated @ModelAttribute("studentform") Student student,
			BindingResult result, ModelMap map) {
		log.info("Inside saveStudent Method in teacher controller class");
		String viewname;
		if (result.hasErrors()) {
			log.info("Error while saving Student in teacher controller class");
			viewname = "StudentRegistration";
		} else {
			log.info("Saving Student in teacher controller class");
			
			if(student.getStudentid() == 0){
				//new person, add it
				this.studentservice1.saveStudent(student);
			}else{
				//existing person, call update
				this.studentservice1.updateStudent(student);
			}
			viewname = "TeacherHome";
		}
		return viewname;
	}	
	
	//To update Enotes
		@RequestMapping(value = "/addEnotes", method = RequestMethod.GET)
		public String addEnotes(ModelMap map) {
			log.info("Inside addTimeTable method in teacher controller class");
			Enotes enotes=new Enotes();
			map.addAttribute("enotesform",enotes);
			return "UpdateENotes";
		}
		
		//To update Time Table
		@RequestMapping(value = "/addTimeTable", method = RequestMethod.GET)
		public String addTimeTable(ModelMap map) {
			log.info("Inside addTimeTable method in teacher controller class");
			TimeTable timetable=new TimeTable();
			map.addAttribute("timetableform",timetable);
			return "UpdateTimeTable";
		}
		
		//Save time table details
		@RequestMapping(value = "/saveTimeTable", method = RequestMethod.POST)
		public String saveTimeTable(@Validated @ModelAttribute("timetableform") TimeTable timetable,
				BindingResult result, ModelMap map) {
			log.info("Inside saveTimeTable Method in teacher controller class");
			String viewname;
			if (result.hasErrors()) {
				log.info("Error while saveTimeTable in teacher controller class");
				viewname = "UpdateTimeTable";
			} else {
				
				if(timetable.getTimeTableId() == null){
					log.info("Saving TimeTable in teacher controller class");
					teacherservice.saveTimetable(timetable);
				}else{
					//existing person, call update
					log.info("updating TimeTable in teacher controller class");
					teacherservice.updateTimetable(timetable);
				}
				viewname = "TeacherHome";
			}
			return viewname;
		}
	
		//Save Enotes
		@RequestMapping(value = "/saveEnotes", method = RequestMethod.POST)
			public String saveEnotes(@Validated @ModelAttribute("enotesform") Enotes enotes,
					BindingResult result, ModelMap map) {
				log.info("Inside saveEnotes method in teacher controller class");
				String viewname;
				if (result.hasErrors()) {
					log.info("Error while saving enotes in Teacher Controller");
					viewname = "UpdateENotes";
				} else {
					if(enotes.getEnotesId() == null){
						log.info("saving enotes in Teacher Controller");

						teacherservice.saveEnotes(enotes);
					}else{
						log.info("updating enotes in Teacher Controller");

						//existing person, call update
						teacherservice.updateEnotes(enotes);
					}
					
					viewname = "TeacherHome";
				}
				return viewname;
			}
	
	//remove student
	@RequestMapping("/remove/{Studentid}")
    public String removeStudent(@PathVariable("Studentid") int Studentid){
		log.info("Inside removeStudent Method in teacher controller class");
		this.studentservice1.removeStudent(Studentid);
        return "TeacherHome";
    }
 
	//update student
    @RequestMapping("/edit/{Studentid}")
    public String editStudent(@PathVariable("Studentid") int Studentid, Model model){
    	log.info("Inside editStudent Method in teacher controller class");
        model.addAttribute("studentform", this.studentservice1.getStudentById(Studentid));
        model.addAttribute("listStudents", this.studentservice1.fetchStudentList());
        return "StudentRegistration";
    }
    
    
    
    
    
  //remove Enotes
  	@RequestMapping("/removeEnotes/{enotesId}")
      public String removeEnotes(@PathVariable("enotesId") int enotesId, ModelMap map){
  		log.info("Inside removeEnotes Method in teacher controller class");
  		this.studentservice1.removeEnotes(enotesId);
  		List<Enotes> enoteslist = studentservice.fetchEnotesList(selectedStandard);
		map.addAttribute("enoteslist", enoteslist);
		return "DisplayENotesTeacher";
      }
   
  //remove Enotes
  	@RequestMapping("/removeTimetable/{TimeTableId}")
      public String removeTimetable(@PathVariable("TimeTableId") int TimeTableId, ModelMap map){
  		log.info("Inside removeTimetable Method in teacher controller class");
  		this.studentservice1.removeTimeTable(TimeTableId);
  		List<TimeTable> timetablelist = studentservice.fetchTimeTableList(selectedStandard);
		map.addAttribute("timetablelist", timetablelist);
		return "DisplayTimeTableTeacher";
      }
   
  	//update Enotes
      @RequestMapping("/editTimetable/{TimeTableId}")
      public String editTimetable(@PathVariable("TimeTableId") int TimeTableId, Model model){
      	log.info("Inside editTimetable Method in teacher controller class");
          model.addAttribute("timetableform", this.studentservice1.getTimeTableByTimeTableId(TimeTableId));			
         return "UpdateTimeTable";
      }
  	
  	//update Enotes
      @RequestMapping("/editEnotes/{enotesId}")
      public String editEnotes(@PathVariable("enotesId") int enotesId, Model model){
      	log.info("Inside editEnotes Method in teacher controller class");
          model.addAttribute("enotesform", this.studentservice1.getEnotesByEnotesId(enotesId));			
         return "UpdateENotes";
      }
	
	
	//Logout teacher
	@RequestMapping("/teacherlogout")
	public String logout(HttpServletRequest request)
	{
	  	log.info("Inside logout Method in teacher controller class");
		request.getSession().invalidate();
		return "HomePage";
	}
	
	// Displaying MyFeedback details
		@RequestMapping(value = "/myFeedback")
		public String FeedbackDetails(ModelMap map) {	
		  	log.info("Inside FeedbackDetails Method in teacher controller class");
			List<TeacherFeedback> feedbacklist = teacherservice.fetchFeedbackList(CurrentTeacher.getTeacherName());
			map.addAttribute("feedbacklist", feedbacklist);
			return "DisplayTeacherFeedback";
		}
		//Feedback
		@RequestMapping(value = "/StudentFeedback", method = RequestMethod.GET)
		public String Feedback(ModelMap map) {
			log.info("Inside TeacherFeedback Method in teacher controller class");
			StudentFeedback studentFeedback=new StudentFeedback();
			map.addAttribute("studentfeedbackform",studentFeedback);
			return "StudentFeedback";
		}
		
		//Save Feedback
		@RequestMapping(value = "/saveStudentFeedback", method = RequestMethod.POST)
		public String saveFeedback(@Validated @ModelAttribute("studentfeedbackform") StudentFeedback studentFeedback,
				BindingResult result, ModelMap map) {
			log.info("Inside saveStudentFeedback Method in teacher controller class");
			String viewname;
			if (result.hasErrors()) {
				log.info("Error while saving StudentFeedback Details in teacher controller class");
				viewname = "StudentFeedback";
			} else {
				log.info("saving StudentFeedback Details to Service in teacher controller class");
				studentFeedback.setTeacherName(CurrentTeacher.getTeacherName());
				teacherservice.StudentFeedback(studentFeedback);
				viewname = "TeacherHome";
			}
			return viewname;
		}
	
	@ModelAttribute
	public void headerMessage(Model model){
		List<String> standardList = new ArrayList<String>();
		standardList.add("Class-I");
		standardList.add("Class-II");
		standardList.add("Class-III");
		standardList.add("Class-IV");
		standardList.add("Class-V");
		standardList.add("Class-VI");
		standardList.add("Class-VII");
		standardList.add("Class-VIII");
		standardList.add("Class-IX");
		standardList.add("Class-X");
		standardList.add("Class-XI");
		standardList.add("Class-XII");
		
		List<String> subjectList = new ArrayList<String>();
		subjectList.add("Telugu");
		subjectList.add("Hindi");
		subjectList.add("English");
		subjectList.add("Mathematics");
		subjectList.add("Science");
		subjectList.add("Social");
		subjectList.add("General Knowledge");
		subjectList.add("Computers");
		
		
		model.addAttribute("standardList", standardList);
		model.addAttribute("subjectList", subjectList);

		
	}
	
}
