
package com.main.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name = "studentFeedback")
public class StudentFeedback {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer FeedbackId;
	
	@NotNull
	private int studentId;
	
	@NotEmpty
	private String feedback;
	
	private String teacherName;
	
	
	public StudentFeedback()
	{
		
	}


	public StudentFeedback(int studentId, String feedback, String teacherName) {
		super();
		this.studentId = studentId;
		this.feedback = feedback;
		this.teacherName = teacherName;
	}


	public Integer getFeedbackId() {
		return FeedbackId;
	}


	public void setFeedbackId(Integer feedbackId) {
		FeedbackId = feedbackId;
	}


	public int getStudentId() {
		return studentId;
	}


	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}


	public String getFeedback() {
		return feedback;
	}


	public void setFeedback(String feedback) {
		this.feedback = feedback;
	}


	public String getTeacherName() {
		return teacherName;
	}


	public void setTeacherName(String teacherName) {
		this.teacherName = teacherName;
	}
	
}
