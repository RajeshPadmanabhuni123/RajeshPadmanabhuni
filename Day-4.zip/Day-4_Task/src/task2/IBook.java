package task2;

public interface IBook {

	public void daysOverdue(int days);
	public void Overdue(int dayReceived);
	public void computeFine(int duedays);
}
