package task1;

public class English implements Greetings {

	@Override
	public void morning() {
		// TODO Auto-generated method stub
		System.out.println("Good Morning");
		
	}

	@Override
	public void afternoon() {
		// TODO Auto-generated method stub
		System.out.println("Good Afternoon");
	}

	@Override
	public void evening() {
		// TODO Auto-generated method stub
		System.out.println("Good Evening");
	}

	@Override
	public void night() {
		// TODO Auto-generated method stub
		System.out.println("Good night");
	}

}
