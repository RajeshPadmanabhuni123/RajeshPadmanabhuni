package task1;

public interface Greetings {

	public abstract void morning();
	public abstract void afternoon();
	public abstract void evening();
	public abstract void night();
}

