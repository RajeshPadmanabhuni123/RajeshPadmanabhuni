package task1;
/**
 * 
 * @author RajeshRockzz
 *
 */
public class Main_Greetings {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Greetings e=new English();
		e.morning();
		e.afternoon();
		e.evening();
		e.night();
		e=new Telugu();
		e.morning();
		e.afternoon();
		e.evening();
		e.night();
		e=new Hindi();
		e.morning();
		e.afternoon();
		e.evening();
		e.night();
	}

}
