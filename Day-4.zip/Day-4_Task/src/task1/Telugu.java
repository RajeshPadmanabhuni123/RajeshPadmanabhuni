package task1;

public class Telugu implements Greetings{

	@Override
	public void morning() {
		// TODO Auto-generated method stub
		System.out.println("Namaskar");
		
	}

	@Override
	public void afternoon() {
		// TODO Auto-generated method stub
		System.out.println("Namaskar");
	}

	@Override
	public void evening() {
		// TODO Auto-generated method stub
		System.out.println("Namaskar");
	}

	@Override
	public void night() {
		// TODO Auto-generated method stub
		System.out.println("Namaskar");
	}
}
