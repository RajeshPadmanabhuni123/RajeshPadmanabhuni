package task1;

public class Hindi implements Greetings{

	@Override
	public void morning() {
		// TODO Auto-generated method stub
		System.out.println("Shubodaya");
		
	}

	@Override
	public void afternoon() {
		// TODO Auto-generated method stub
		System.out.println("Shubdopahar");
	}

	@Override
	public void evening() {
		// TODO Auto-generated method stub
		System.out.println("Shubsandhya");
	}

	@Override
	public void night() {
		// TODO Auto-generated method stub
		System.out.println("Shubratri");
	}
}
