create database onlineFoodOrderingDB;

create table restaurants(restaurantid int primary key auto_increment, restaurantname varchar(30), restaurantaddress varchar(30), restaurantcity varchar(30), contactno bigint);

insert into restaurants(restaurantname, restaurantaddress, restaurantcity, contactno) values(101,'punjabi daba','annamayya circle','nellore','99988877766');

insert into restaurants(restaurantname, restaurantaddress, restaurantcity, contactno) values('murali krishna','rtc','nellore','79797979');

insert into restaurants(restaurantname, restaurantaddress, restaurantcity, contactno) values('prabha grand','lrode','chittor','656412345');

insert into restaurants(restaurantname, restaurantaddress, restaurantcity, contactno) values('karthikeya','singh nagar','chittor','66554411');

insert into restaurants(restaurantname, restaurantaddress, restaurantcity, contactno) values('ming garden','pk street','vizag','3694152335');

insert into restaurants(restaurantname, restaurantaddress, restaurantcity, contactno) values('itlian spicy','ck street','vijayawada','12224156');

insert into restaurants(restaurantname, restaurantaddress, restaurantcity, contactno) values('gem bars','dk street','vijayawada','654643256');

insert into restaurants(restaurantname, restaurantaddress, restaurantcity, contactno) values('v grand','jk street','ongole','541346526');

insert into restaurants(restaurantname, restaurantaddress, restaurantcity, contactno) values('okra','big street','hyderabad','4363843468');

insert into restaurants(restaurantname, restaurantaddress, restaurantcity, contactno) values('firdaus','23 road','hyderabad','9543423452');

select * from restaurants;

create table rmenuitems(menuid int primary key auto_increment, restid int,menuname varchar(30),menutype varchar(30),menucategory varchar(30), menuprice float,menudesc varchar(20),foreign key(restid) references restaurants(restaurantid));

insert into rmenuitems values(501,101,'south indian','veg','staters',1500,'veg manchuria');

insert into rmenuitems(restid ,menuname,menutype ,menucategory , menuprice ,menudesc) values(102,'south indian','veg','main course',3500,'Biryani');

insert into rmenuitems(restid ,menuname,menutype ,menucategory , menuprice ,menudesc) values(102,'north indian','non veg','main course',7000,'bahubali tali');

insert into rmenuitems(restid ,menuname,menutype ,menucategory , menuprice ,menudesc) values(105,'italian','veg','non veg',1500,'pizza');

insert into rmenuitems(restid ,menuname,menutype ,menucategory , menuprice ,menudesc) values(105,'chinese','veg','veg',500,'noodles');

insert into rmenuitems(restid ,menuname,menutype ,menucategory , menuprice ,menudesc) values(107,'mexican','non veg','veg',1500,'franky');

insert into rmenuitems(restid ,menuname,menutype ,menucategory , menuprice ,menudesc) values(108,'south indian','veg','main course',2500,'palav');


insert into rmenuitems(restid ,menuname,menutype ,menucategory , menuprice ,menudesc) values(103,'south indian','veg','main course',2500,'butter nan');

insert into rmenuitems(restid ,menuname,menutype ,menucategory , menuprice ,menudesc) values(104,'south indian','veg','main course',5500,'kadai paneer');

insert into rmenuitems(restid ,menuname,menutype ,menucategory , menuprice ,menudesc) values(106,'south indian','veg','main course',2520,'sambar rice');

insert into rmenuitems(restid ,menuname,menutype ,menucategory , menuprice ,menudesc) values(109,'south indian','veg','breakfast',2540,'dosa');

insert into rmenuitems(restid ,menuname,menutype ,menucategory , menuprice ,menudesc) values(110,'south indian','veg','main course',2505,'palav');

create table customers(customerid int primary key, customername varchar(30), customercity varchar(30), customerdob date, customergender varchar(10) check(customergender='male' or customergender='female'), customerpassword varchar(30));

desc customers;

insert into customers values(1,'rajesh','nellore','1999-03-12','male','Rajesh@');

insert into customers values(2,'akshith','ongole','1998-04-20','male','akshith@');

insert into customers values(3,'vignesh','madurai','1989-09-22','male','vignesh@');

insert into customers values(5,'vishnuPriya','nellore','1979-04-10','female','vishnuPriya@');

insert into customers values(6,'keerthi','nellore','1989-05-11','female','keerthi@');

insert into customers values(7,'anusha','banglore','1998-02-06','female','anusha@');

insert into customers values(8,'nihitha','vizag','1799-05-10','female','nihitha@');

select * from customers;

create table orders(orderid int primary key auto_increment, customerid int,orderdate date,deliveryaddress varchar(30),orderstatus varchar(20) check(orderstatus='delivered' or orderstatus='enroute' or orderstatus='cancelled'), foreign key(customerid) references customers(customerid));

insert into orders values(901,1,'2020-10-20','nellore','delivered');

insert into orders(customerid ,orderdate ,deliveryaddress ,orderstatus) values(1,'2020-10-20','nellore','cancelled');


insert into orders(customerid ,orderdate ,deliveryaddress ,orderstatus) values(2,'2020-11-10','ongole','enroute');

insert into orders(customerid ,orderdate ,deliveryaddress ,orderstatus) values(3,'2010-10-20','madurai','enroute');

insert into orders(customerid ,orderdate ,deliveryaddress ,orderstatus) values(5,'2010-10-20','banglore','cancelled');

insert into orders(customerid ,orderdate ,deliveryaddress ,orderstatus) values(6,'2020-11-09','nellore','enroute');

insert into orders(customerid ,orderdate ,deliveryaddress ,orderstatus) values(7,'2020-10-22','banglore','delivered');

insert into orders(customerid ,orderdate ,deliveryaddress ,orderstatus) values(5,'2020-10-20','chennai','enroute');

insert into orders(customerid ,orderdate ,deliveryaddress ,orderstatus) values(6,'2020-07-20','nellore','delivered');

create table ordermenus(orderid int not null , menuid int not null, menuqty int, menuprice float, foreign key(orderid) references orders(orderid),foreign key(menuid) references rmenuitems(menuid));

desc ordermenus;
insert into ordermenus values(901,501,2,1500);

insert into ordermenus values(902,501,2,1500);

insert into ordermenus values(902,502,2,3500);

insert into ordermenus values(904,502,2,3500);

insert into ordermenus values(906,503,2,7000);

insert into ordermenus values(906,503,2,7000);

insert into ordermenus values(908,503,2,7000);

insert into ordermenus values(909,504,2,1500);

insert into ordermenus values(909,507,2,2500);

insert into ordermenus values(903,506,2,500);

insert into ordermenus values(901,505,2,1500);

insert into ordermenus values(901,503,2,7000);

insert into ordermenus values(905,504,4,1500);

insert into ordermenus values(907,501,2,1500);



select restaurantcity from restaurants where restaurantcity='nellore';

select restaurants.restaurantid,restaurants.restaurantname,rmenuitems.menuid,rmenuitems.menuname,rmenuitems.menuprice from restaurants inner join rmenuitems on rmenuitems.restid=restaurants.restaurantid;

select restaurants.restaurantid,restaurants.restaurantname,rmenuitems.menuid,rmenuitems.menuname,rmenuitems.menuprice from restaurants inner join rmenuitems on rmenuitems.restid=restaurants.restaurantid where restaurants.restaurantcity='nellore';

select * from orders where customerid=1;

select * from orders inner join ordermenus on orders.orderid=ordermenus.orderid where orders.customerid=1;

select * from orders where customerid=1 order by orderid desc limit 5;

select * from rmenuitems where menuid not in (select menuid from onlinefoodorderingdb.ordermenus group by menuid order by count(*) desc);


select menuid from onlinefoodorderingdb.ordermenus group by menuid order by count(*) desc;

select * from rmenuitems where menuid in (select menuid from onlinefoodorderingdb.ordermenus group by menuid order by count(*) desc);









